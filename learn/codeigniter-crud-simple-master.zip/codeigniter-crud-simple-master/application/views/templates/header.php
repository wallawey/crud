<html>
	<head>
		<title>CodeIgniter Tutorial</title>
	</head>
	<body>
		<h1>Simple CRUD</h1>
		<p><a href="<?php echo site_url('news'); ?>">Home</a> | <a href="<?php echo site_url('news/create'); ?>">Add News</a></p>
