<p>News added successfully!</p>
