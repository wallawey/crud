CodeIgniter: Simple Add, Edit, Delete, View – MVC CRUD Application
========

A simple and basic CRUD application using CodeIgniter PHP Framework.

Blog Article: [CodeIgniter: Simple Add, Edit, Delete, View – MVC CRUD Application](http://blog.chapagain.com.np/codeigniter-simple-mvc-crud-add-edit-delete-view/)
