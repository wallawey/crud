"Simple CRUD - SpringMVC & Hibernate" is just simple (there's no complex business rule) and built using SpringMVC and Hibernate3. You're free to use or alter this code for whatever your intentions :)

Requirements:
- Netbeans 6.5
- Application Server (e.g. Glassfish2)
- MySql 5

Steps to run:
1. extract Simple CRUD - SpringMVC & Hibernate3.zip
2. open project using netbeans 6.5
3. resolve missing library by adding below library (available from http://commons.apache.org/)
-commons-pool.jar
-commons-dbcp.jar
4. run script at project_folder/docs/ddl_dml.sql
5. run project..
6. that's all...

Regards,
henrihnr