Simple CRUD Application is just simple (there's no complex business rule) and built using CodeIgniter-1.6.3. You're free to use or alter this code for whatever your intentions :)

Requirements:
- Web Server (Apache)
- PHP
- MySql

Steps to run:
1. extract CodeIgniter.zip to your www folder
2. set your base site url at CodeIgniter/system/application/config/config.php
3. set your database connection properties at CodeIgniter/system/application/config/config.php
4. run script at CodeIgniter/docs/ddl_dml.sql
5. that's all...

Regards,
henrihnr